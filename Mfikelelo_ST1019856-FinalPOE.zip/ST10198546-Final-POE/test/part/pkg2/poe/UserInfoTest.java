/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package part.pkg2.poe;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class UserInfoTest {
    
    public UserInfoTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of setNumberOfTask method, of class UserInfo.
     */
    @Test
    public void testSetNumberOfTask() {
    }

    /**
     * Test of getNumberOfTask method, of class UserInfo.
     */
    @Test
    public void testGetNumberOfTask() {
    }

    /**
     * Test of setTaskName method, of class UserInfo.
     */
    @Test
    public void testSetTaskName() {
    }

    /**
     * Test of getTaskName method, of class UserInfo.
     */
    @Test
    public void testGetTaskName() {
    }

    /**
     * Test of setTaskNumber method, of class UserInfo.
     */
    @Test
    public void testSetTaskNumber() {
    }

    /**
     * Test of getTaskNumber method, of class UserInfo.
     */
    @Test
    public void testGetTaskNumber() {
    }

    /**
     * Test of setDiscription method, of class UserInfo.
     */
    @Test
    public void testSetDiscription() {
    }

    /**
     * Test of getDiscription method, of class UserInfo.
     */
    @Test
    public void testGetDiscription() {
    }

    /**
     * Test of setDeveloperNames method, of class UserInfo.
     */
    @Test
    public void testSetDeveloperNames() {
    }

    /**
     * Test of getDeveloperNames method, of class UserInfo.
     */
    @Test
    public void testGetDeveloperNames() {
    }

    /**
     * Test of setDuration method, of class UserInfo.
     */
    @Test
    public void testSetDuration() {
    }

    /**
     * Test of getDuration method, of class UserInfo.
     */
    @Test
    public void testGetDuration() {
    }

    /**
     * Test of setStatus method, of class UserInfo.
     */
    @Test
    public void testSetStatus() {
    }

    /**
     * Test of getStatus method, of class UserInfo.
     */
    @Test
    public void testGetStatus() {
    }

    /**
     * Test of WelcomeNote method, of class UserInfo.
     */
    @Test
    public void testWelcomeNote() {
    }
    
}
