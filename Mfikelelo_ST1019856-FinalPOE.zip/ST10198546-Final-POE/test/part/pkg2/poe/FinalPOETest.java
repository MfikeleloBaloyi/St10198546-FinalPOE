/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package part.pkg2.poe;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class FinalPOETest {
    
    public FinalPOETest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of manipulateArrays method, of class FinalPOE.
     */
    @Test
    public void testManipulateArrays() {
    }

    /**
     * Test of doneTasks method, of class FinalPOE.
     */
    @Test
    public void testDoneTasks() {
    }

    /**
     * Test of longestTask method, of class FinalPOE.
     */
    @Test
    public void testLongestTask() {
    }

    /**
     * Test of searchTask method, of class FinalPOE.
     */
    @Test
    public void testSearchTask() {
    }

    /**
     * Test of developerTasks method, of class FinalPOE.
     */
    @Test
    public void testDeveloperTasks() {
    }

    /**
     * Test of deleteTask method, of class FinalPOE.
     */
    @Test
    public void testDeleteTask() {
    }

    /**
     * Test of displayReport method, of class FinalPOE.
     */
    @Test
    public void testDisplayReport() {
    }
    
}
